
public class Driver {
	public static void main(String[] args)
	{
		CardWindow cd = new CardWindow();
		cd.setVisible(true);
	}
}
