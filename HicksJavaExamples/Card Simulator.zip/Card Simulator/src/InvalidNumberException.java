
public class InvalidNumberException extends Exception{
	
	public InvalidNumberException()
	{
		
	}
	
	public InvalidNumberException(String message)
	{
		super(message);
	}
}
