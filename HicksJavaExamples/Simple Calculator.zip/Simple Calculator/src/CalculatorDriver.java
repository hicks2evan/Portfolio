/**
 * CalculatorDriver.java
 * @author Evan Hicks
 *Drives the Calculator class.
 */
public class CalculatorDriver {
	public static void main(String[] args) {
		Calculator myCalculator = new Calculator();
		myCalculator.run();
	}

}
