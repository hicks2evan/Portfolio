
public interface MessageEncoder {
	public String encode(String plainText);
}
